# Databricks notebook source
# Install XGBoost

%pip install xgboost

# COMMAND ----------

import pandas as pd
import numpy as np
import time
import json
import pickle

from sklearn.model_selection import train_test_split

from sklearn.preprocessing import LabelEncoder

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score
)

from sklearn.linear_model import LogisticRegression

from sklearn.tree import DecisionTreeClassifier

from sklearn.ensemble import RandomForestClassifier

from xgboost import XGBClassifier

# COMMAND ----------

df = pd.read_csv(
"/Workspace/Users/kpspragathi@gmail.com/PrognexaAI/diabetic_data.csv"
)

print(df.shape)

df.head()

# COMMAND ----------

mapping = pd.read_csv(
"/Workspace/Users/kpspragathi@gmail.com/PrognexaAI/IDS_mapping.csv"
)

mapping.head()

# COMMAND ----------

df.isnull().sum()

# COMMAND ----------

df.replace("?", np.nan, inplace=True)

# COMMAND ----------

drop_cols = [
    "weight",
    "payer_code",
    "medical_specialty"
]

df.drop(columns=drop_cols, inplace=True)

# COMMAND ----------

for col in df.columns:

    if df[col].dtype=="object":

        df[col]=df[col].fillna(df[col].mode()[0])

    else:

        df[col]=df[col].fillna(df[col].median())

# COMMAND ----------

df["SeniorCitizen"]=df["age"].apply(
lambda x:1 if int(x.strip("[)").split("-")[0])>=65 else 0
)

df["LongStay"]=(df["time_in_hospital"]>7).astype(int)

df["FrequentVisitor"]=(
df["number_outpatient"]+
df["number_emergency"]
>5
).astype(int)

# COMMAND ----------

encoders={}

categorical=df.select_dtypes(include="object").columns

categorical

# COMMAND ----------

for col in categorical:

    le=LabelEncoder()

    df[col]=le.fit_transform(df[col].astype(str))

    encoders[col]=le

# COMMAND ----------

target="readmitted"

X=df.drop(columns=[target])

y=df[target]

# COMMAND ----------

X_train,X_test,y_train,y_test=train_test_split(

X,

y,

test_size=0.2,

random_state=42,

stratify=y

)

# COMMAND ----------

models={

"Logistic Regression":
LogisticRegression(max_iter=1000),

"Decision Tree":
DecisionTreeClassifier(random_state=42),

"Random Forest":
RandomForestClassifier(
n_estimators=200,
random_state=42
),

"XGBoost":
XGBClassifier(
random_state=42,
eval_metric="logloss"
)

}

# COMMAND ----------

print(df["readmitted"].value_counts())

print(y.unique())

# COMMAND ----------

print(df["readmitted"].head(10))

# COMMAND ----------

# Convert encoded target to binary
# Current encoding:
# 0 = <30
# 1 = >30
# 2 = NO

df["readmitted"] = df["readmitted"].replace({
    0: 1,   # <30 -> Readmitted
    1: 0,   # >30 -> Not readmitted
    2: 0    # NO -> Not readmitted
})

# COMMAND ----------

target = "readmitted"

X = df.drop(columns=[target])
y = df[target]

# COMMAND ----------

print(df["readmitted"].value_counts())
print(y.unique())

# COMMAND ----------

from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

# COMMAND ----------

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

# COMMAND ----------

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score
)

import pandas as pd
import time

# COMMAND ----------

models = {

    "Logistic Regression":
        LogisticRegression(max_iter=1000),

    "Decision Tree":
        DecisionTreeClassifier(random_state=42),

    "Random Forest":
        RandomForestClassifier(
            n_estimators=100,
            random_state=42
        ),

    "XGBoost":
        XGBClassifier(
            random_state=42,
            eval_metric="logloss"
        )

}

# COMMAND ----------

results = []

for name, model in models.items():

    start = time.time()

    model.fit(X_train, y_train)

    training_time = time.time() - start

    pred = model.predict(X_test)

    prob = model.predict_proba(X_test)[:,1]

    results.append({

        "Model": name,

        "Accuracy":
            accuracy_score(y_test, pred),

        "Precision":
            precision_score(y_test, pred),

        "Recall":
            recall_score(y_test, pred),

        "F1 Score":
            f1_score(y_test, pred),

        "ROC AUC":
            roc_auc_score(y_test, prob),

        "Training Time (sec)":
            training_time

    })

# COMMAND ----------

comparison = pd.DataFrame(results)

comparison = comparison.sort_values(
    by="ROC AUC",
    ascending=False
)

comparison

# COMMAND ----------

comparison.to_csv(
    "/Workspace/Users/kpspragathi@gmail.com/PrognexaAI/model_comparison.csv",
    index=False
)

print("Comparison table saved successfully!")

# COMMAND ----------

best = comparison.iloc[0]

print("Best Model :", best["Model"])
print("Accuracy   :", round(best["Accuracy"],4))
print("ROC AUC    :", round(best["ROC AUC"],4))
print("Training Time :", round(best["Training Time (sec)"],4),"seconds")

# COMMAND ----------

from xgboost import XGBClassifier

scale = len(y_train[y_train==0]) / len(y_train[y_train==1])

model = XGBClassifier(
    random_state=42,
    eval_metric="logloss",
    scale_pos_weight=scale
)