# Databricks notebook source
# MAGIC %pip install xgboost

# COMMAND ----------

# MAGIC %pip install imbalanced-learn

# COMMAND ----------

import pandas as pd
import numpy as np
import time

from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split

from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score
)

# COMMAND ----------

df = pd.read_csv(
    "/Workspace/Users/kpspragathi@gmail.com/PrognexaAI/diabetic_data.csv"
)

print(df.shape)
df.head()

# COMMAND ----------

df.replace("?", np.nan, inplace=True)

drop_cols = [
    "weight",
    "payer_code",
    "medical_specialty"
]

df.drop(columns=drop_cols, inplace=True)

for col in df.columns:

    if df[col].dtype == "object":

        df[col] = df[col].fillna(df[col].mode()[0])

    else:

        df[col] = df[col].fillna(df[col].median())

# COMMAND ----------

df["SeniorCitizen"] = (
    df["age"]
      .str.extract(r'(\d+)')
      .astype(int) >= 65
).astype(int)

df["LongStay"] = (
    df["time_in_hospital"] > 7
).astype(int)

df["FrequentVisitor"] = (
    df["number_outpatient"] +
    df["number_emergency"]
    > 5
).astype(int)

# COMMAND ----------

encoders = {}

categorical = df.select_dtypes(include="object").columns

for col in categorical:

    if col != "readmitted":

        le = LabelEncoder()

        df[col] = le.fit_transform(df[col].astype(str))

        encoders[col] = le

# COMMAND ----------

def evaluate_models(target_name, positive_type):

    data = df.copy()

    if positive_type == "any":

        data["target"] = np.where(
            data["readmitted"] == "NO",
            0,
            1
        )

    elif positive_type == "early":

        data["target"] = np.where(
            data["readmitted"] == "<30",
            1,
            0
        )

    X = data.drop(columns=["readmitted","target"])

    y = data["target"]

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.20,
        random_state=42,
        stratify=y
    )

    scale = len(y_train[y_train==0]) / len(y_train[y_train==1])

    models = {

        "Logistic Regression":
            LogisticRegression(max_iter=1000),

        "Decision Tree":
            DecisionTreeClassifier(random_state=42),

        "Random Forest":
            RandomForestClassifier(
                random_state=42
            ),

        "XGBoost":
            XGBClassifier(
                random_state=42,
                eval_metric="logloss",
                scale_pos_weight=scale
            )

    }

    results=[]

    for name,model in models.items():

        start=time.time()

        model.fit(X_train,y_train)

        train_time=time.time()-start

        pred=model.predict(X_test)

        prob=model.predict_proba(X_test)[:,1]

        results.append({

            "Model":name,

            "Accuracy":
            accuracy_score(y_test,pred),

            "Precision":
            precision_score(y_test,pred),

            "Recall":
            recall_score(y_test,pred),

            "F1 Score":
            f1_score(y_test,pred),

            "ROC AUC":
            roc_auc_score(y_test,prob),

            "Training Time (sec)":
            train_time

        })

    comparison=pd.DataFrame(results)

    comparison=comparison.sort_values(
        by="ROC AUC",
        ascending=False
    )

    print("\n")
    print("="*70)
    print(target_name)
    print("="*70)

    display(comparison)

    return comparison

# COMMAND ----------

comparison_any = evaluate_models(

    target_name="TARGET 1 : ANY READMISSION",

    positive_type="any"

)

# COMMAND ----------

comparison_early = evaluate_models(

    target_name="TARGET 2 : EARLY READMISSION (<30)",

    positive_type="early"

)